---
title: "readme"
author: "Brooke Parker"
output: html_document
date: "2022-11-15"
---






# data.cleaner

<!-- badges: start -->
<!-- badges: end -->

The goal of data.cleaner is to ...

## Installation

You can install the development version of data.cleaner like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(data.cleaner)
## basic example code
```

