---
title: "readme"
author: "Brooke Parker"
output: html_document
date: "2022-11-15"
---






# clean.plot

<!-- badges: start -->
<!-- badges: end -->

The goal of clean.plot is to ...

## Installation

You can install the development version of clean.plot like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(clean.plot)
## basic example code
```

